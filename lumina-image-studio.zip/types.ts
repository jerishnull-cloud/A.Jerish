
export type AspectRatio = "1:1" | "4:3" | "3:4" | "16:9" | "9:16";

export interface GeneratedImage {
  id: string;
  url: string;
  prompt: string;
  aspectRatio: AspectRatio;
  timestamp: number;
  quality: 'standard' | 'high';
}

export interface GenerationSettings {
  aspectRatio: AspectRatio;
  quality: 'standard' | 'high';
  imageSize: '1K' | '2K' | '4K';
}
