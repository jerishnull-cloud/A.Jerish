
import React, { useState, useEffect, useCallback } from 'react';
import { generateImage } from './geminiService';
import { AspectRatio, GeneratedImage, GenerationSettings } from './types';

// Components
const AspectRatioSelector: React.FC<{
  current: AspectRatio;
  onChange: (ratio: AspectRatio) => void;
}> = ({ current, onChange }) => {
  const ratios: AspectRatio[] = ["1:1", "4:3", "3:4", "16:9", "9:16"];
  
  return (
    <div className="flex flex-wrap gap-2">
      {ratios.map((ratio) => (
        <button
          key={ratio}
          onClick={() => onChange(ratio)}
          className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
            current === ratio
              ? "bg-indigo-600 text-white border-indigo-500 shadow-lg shadow-indigo-900/20"
              : "bg-zinc-800 text-zinc-400 border border-zinc-700 hover:border-zinc-500"
          }`}
        >
          {ratio}
        </button>
      ))}
    </div>
  );
};

const HistoryCard: React.FC<{
  image: GeneratedImage;
  onClick: (image: GeneratedImage) => void;
}> = ({ image, onClick }) => {
  return (
    <div 
      onClick={() => onClick(image)}
      className="group relative cursor-pointer overflow-hidden rounded-xl border border-zinc-800 bg-zinc-900 transition-all hover:border-zinc-600"
    >
      <img 
        src={image.url} 
        alt={image.prompt} 
        className="aspect-square w-full object-cover transition-transform duration-500 group-hover:scale-110"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 transition-opacity group-hover:opacity-100 p-3 flex flex-col justify-end">
        <p className="text-[10px] text-zinc-300 line-clamp-2">{image.prompt}</p>
      </div>
    </div>
  );
};

export default function App() {
  const [prompt, setPrompt] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentImage, setCurrentImage] = useState<GeneratedImage | null>(null);
  const [history, setHistory] = useState<GeneratedImage[]>([]);
  const [settings, setSettings] = useState<GenerationSettings>({
    aspectRatio: "1:1",
    quality: "standard",
    imageSize: "1K"
  });

  const handleGenerate = async () => {
    if (!prompt.trim()) return;

    // Check for high quality requirements
    if (settings.quality === 'high') {
      const hasKey = await (window as any).aistudio?.hasSelectedApiKey();
      if (!hasKey) {
        await (window as any).aistudio?.openSelectKey();
        // After opening dialog, we proceed. Some environments might need a reload, 
        // but we assume the key is now available in process.env.API_KEY.
      }
    }

    setIsGenerating(true);
    setError(null);

    try {
      const imageUrl = await generateImage(prompt, settings);
      const newImage: GeneratedImage = {
        id: Date.now().toString(),
        url: imageUrl,
        prompt: prompt,
        aspectRatio: settings.aspectRatio,
        timestamp: Date.now(),
        quality: settings.quality,
      };

      setCurrentImage(newImage);
      setHistory(prev => [newImage, ...prev]);
    } catch (err: any) {
      let message = "An unexpected error occurred.";
      if (err.message?.includes("Requested entity was not found")) {
        message = "Project or API Key issue. Try selecting your API key again.";
        // Reset key state to prompt re-selection if possible
      } else {
        message = err.message || "Failed to generate image. Please try again.";
      }
      setError(message);
    } finally {
      setIsGenerating(false);
    }
  };

  const downloadImage = (image: GeneratedImage) => {
    const link = document.createElement("a");
    link.href = image.url;
    link.download = `lumina-${image.id}.png`;
    link.click();
  };

  return (
    <div className="min-h-screen flex flex-col bg-zinc-950 text-zinc-100">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-zinc-800 bg-zinc-950/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <i className="fa-solid fa-sparkles text-white"></i>
            </div>
            <h1 className="text-xl font-bold tracking-tight">Lumina</h1>
          </div>
          <div className="flex gap-4">
            <a 
              href="https://ai.google.dev/gemini-api/docs/billing" 
              target="_blank" 
              className="text-xs text-zinc-400 hover:text-zinc-200 transition-colors"
            >
              Billing Docs
            </a>
          </div>
        </div>
      </header>

      <main className="flex-1 flex flex-col md:flex-row max-w-7xl w-full mx-auto px-4 py-8 gap-8 overflow-hidden">
        
        {/* Sidebar Controls */}
        <aside className="w-full md:w-80 flex flex-col gap-6 flex-shrink-0">
          <section className="space-y-4">
            <h2 className="text-sm font-semibold text-zinc-400 uppercase tracking-wider">Parameters</h2>
            
            <div className="space-y-3">
              <label className="block text-sm font-medium text-zinc-300">Aspect Ratio</label>
              <AspectRatioSelector 
                current={settings.aspectRatio} 
                onChange={(ratio) => setSettings(prev => ({ ...prev, aspectRatio: ratio }))} 
              />
            </div>

            <div className="space-y-3">
              <label className="block text-sm font-medium text-zinc-300">Quality Mode</label>
              <div className="grid grid-cols-2 gap-2 p-1 bg-zinc-900 rounded-lg border border-zinc-800">
                <button
                  onClick={() => setSettings(prev => ({ ...prev, quality: 'standard' }))}
                  className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
                    settings.quality === 'standard' ? 'bg-zinc-800 text-white shadow-sm' : 'text-zinc-500'
                  }`}
                >
                  Standard
                </button>
                <button
                  onClick={() => setSettings(prev => ({ ...prev, quality: 'high' }))}
                  className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
                    settings.quality === 'high' ? 'bg-indigo-600/20 text-indigo-400 shadow-sm' : 'text-zinc-500'
                  }`}
                >
                  Ultra (HD)
                </button>
              </div>
            </div>

            {settings.quality === 'high' && (
              <div className="space-y-3 animate-in fade-in duration-300">
                <label className="block text-sm font-medium text-zinc-300">Resolution</label>
                <div className="flex gap-2">
                  {['1K', '2K', '4K'].map((size) => (
                    <button
                      key={size}
                      onClick={() => setSettings(prev => ({ ...prev, imageSize: size as any }))}
                      className={`flex-1 px-3 py-1.5 rounded-md text-xs font-medium border transition-all ${
                        settings.imageSize === size 
                          ? 'bg-indigo-600/10 border-indigo-500 text-indigo-400' 
                          : 'bg-zinc-900 border-zinc-800 text-zinc-500'
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
                <p className="text-[10px] text-zinc-500 italic">Ultra mode requires a high-tier Gemini model session.</p>
              </div>
            )}
          </section>

          <section className="space-y-4 pt-6 border-t border-zinc-900">
            <h2 className="text-sm font-semibold text-zinc-400 uppercase tracking-wider">History</h2>
            <div className="grid grid-cols-2 gap-3 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
              {history.map((img) => (
                <HistoryCard 
                  key={img.id} 
                  image={img} 
                  onClick={(image) => setCurrentImage(image)} 
                />
              ))}
              {history.length === 0 && (
                <div className="col-span-2 h-20 flex items-center justify-center border border-dashed border-zinc-800 rounded-lg text-zinc-600 text-xs">
                  No images yet
                </div>
              )}
            </div>
          </section>
        </aside>

        {/* Workspace */}
        <section className="flex-1 flex flex-col gap-6 min-h-0">
          
          {/* Main Display */}
          <div className="flex-1 bg-zinc-900/50 rounded-2xl border border-zinc-800 relative overflow-hidden flex items-center justify-center">
            {currentImage ? (
              <div className="relative group w-full h-full flex items-center justify-center p-4 md:p-12">
                <img 
                  src={currentImage.url} 
                  alt={currentImage.prompt}
                  className="max-w-full max-h-full object-contain rounded-lg shadow-2xl"
                />
                
                {/* Actions Overlay */}
                <div className="absolute top-6 right-6 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button 
                    onClick={() => downloadImage(currentImage)}
                    className="w-10 h-10 bg-black/60 backdrop-blur-md text-white rounded-full flex items-center justify-center hover:bg-black/80 transition-all shadow-lg"
                    title="Download"
                  >
                    <i className="fa-solid fa-download"></i>
                  </button>
                </div>

                <div className="absolute bottom-6 left-1/2 -translate-x-1/2 px-4 py-2 bg-black/60 backdrop-blur-md rounded-full text-xs text-zinc-300 border border-white/10 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                  {currentImage.prompt}
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-4 text-zinc-600">
                <div className="w-16 h-16 rounded-full bg-zinc-900 flex items-center justify-center border border-zinc-800">
                  <i className="fa-solid fa-image text-2xl"></i>
                </div>
                <p className="text-sm font-medium">Your creation will appear here</p>
              </div>
            )}

            {/* Loading State */}
            {isGenerating && (
              <div className="absolute inset-0 bg-black/40 backdrop-blur-sm z-10 flex flex-col items-center justify-center gap-4 animate-in fade-in duration-300">
                <div className="relative">
                  <div className="w-12 h-12 border-4 border-indigo-500/20 border-t-indigo-500 rounded-full animate-spin"></div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <i className="fa-solid fa-sparkles text-indigo-400 animate-pulse"></i>
                  </div>
                </div>
                <div className="text-center space-y-1">
                  <p className="text-sm font-medium text-white">Generating your vision...</p>
                  <p className="text-xs text-zinc-400">Our AI models are crafting every pixel.</p>
                </div>
              </div>
            )}
          </div>

          {/* Prompt Bar */}
          <div className="flex flex-col gap-4">
            {error && (
              <div className="px-4 py-2 bg-red-500/10 border border-red-500/20 text-red-400 text-xs rounded-lg flex items-center gap-2">
                <i className="fa-solid fa-circle-exclamation"></i>
                {error}
              </div>
            )}
            
            <div className="flex gap-3 bg-zinc-900 border border-zinc-800 p-2 rounded-2xl shadow-xl focus-within:border-zinc-600 transition-all">
              <textarea 
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="A surreal landscape with floating islands and neon waterfalls..."
                className="flex-1 bg-transparent border-none focus:ring-0 text-zinc-200 placeholder-zinc-600 text-sm py-2 px-3 resize-none min-h-[44px] max-h-32"
                rows={1}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleGenerate();
                  }
                }}
              />
              <button 
                onClick={handleGenerate}
                disabled={isGenerating || !prompt.trim()}
                className={`px-6 rounded-xl flex items-center gap-2 font-semibold text-sm transition-all h-11 ${
                  isGenerating || !prompt.trim() 
                    ? "bg-zinc-800 text-zinc-600 cursor-not-allowed" 
                    : "bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-500/20"
                }`}
              >
                <span>{isGenerating ? "Crafting..." : "Generate"}</span>
                {!isGenerating && <i className="fa-solid fa-wand-magic-sparkles"></i>}
              </button>
            </div>
          </div>
        </section>
      </main>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #27272a;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #3f3f46;
        }
      `}</style>
    </div>
  );
}
